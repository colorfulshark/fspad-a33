#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
 .name = KBUILD_MODNAME,
 .init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
 .exit = cleanup_module,
#endif
 .arch = MODULE_ARCH_INIT,
};

MODULE_INFO(intree, "Y");

static const struct modversion_info ____versions[]
__used
__attribute__((section("__versions"))) = {
	{ 0xde22caa5, "module_layout" },
	{ 0xa6c8cd46, "input_free_int" },
	{ 0x7485f934, "i2c_master_send" },
	{ 0xe77af6b6, "device_remove_file" },
	{ 0x12da5bb2, "__kmalloc" },
	{ 0xf9a482f9, "msleep" },
	{ 0x15692c87, "param_ops_int" },
	{ 0x2e5810c6, "__aeabi_unwind_cpp_pr1" },
	{ 0xabbce77b, "dev_set_drvdata" },
	{ 0x43a53735, "__alloc_workqueue_key" },
	{ 0xc9d567c, "i2c_del_driver" },
	{ 0x26e7b620, "malloc_sizes" },
	{ 0xbc3f9c29, "i2c_transfer" },
	{ 0x4205ad24, "cancel_work_sync" },
	{ 0x33543801, "queue_work" },
	{ 0x432fd7f6, "__gpio_set_value" },
	{ 0x63588dd8, "input_free_platform_resource" },
	{ 0x91715312, "sprintf" },
	{ 0xe2d5255a, "strcmp" },
	{ 0xd6443013, "input_set_abs_params" },
	{ 0xc51b027b, "input_event" },
	{ 0xe707d823, "__aeabi_uidiv" },
	{ 0xb5eeb329, "register_early_suspend" },
	{ 0x5f754e5a, "memset" },
	{ 0xf51508fd, "dev_err" },
	{ 0x96ba6b3d, "__mutex_init" },
	{ 0x27e1a049, "printk" },
	{ 0xd34bb007, "input_set_int_enable" },
	{ 0x73e20c1c, "strlcpy" },
	{ 0x8c03d20c, "destroy_workqueue" },
	{ 0xbc8e5df, "device_init_wakeup" },
	{ 0x673d42f5, "input_fetch_sysconfig_para" },
	{ 0x42160169, "flush_workqueue" },
	{ 0x2196324, "__aeabi_idiv" },
	{ 0x397d0ff9, "i2c_register_driver" },
	{ 0x7f8d0bf2, "device_create_file" },
	{ 0x5546f22b, "input_request_int" },
	{ 0x3d45355f, "input_init_platform_resource" },
	{ 0x279fb16d, "kmem_cache_alloc" },
	{ 0xfa108142, "input_register_device" },
	{ 0x495ce509, "input_free_device" },
	{ 0x2db230d6, "i2c_master_recv" },
	{ 0x37a0cba, "kfree" },
	{ 0x9d669763, "memcpy" },
	{ 0x694276fc, "input_unregister_device" },
	{ 0xb227ae83, "unregister_early_suspend" },
	{ 0xefd6cf06, "__aeabi_unwind_cpp_pr0" },
	{ 0x676bbc0f, "_set_bit" },
	{ 0x2a3814c5, "dev_get_drvdata" },
	{ 0x85ebc9ca, "input_allocate_device" },
};

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=";

MODULE_ALIAS("i2c:gslX680");
